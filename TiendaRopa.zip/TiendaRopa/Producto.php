<!DOCTYPE html> 
<meta charset="UTF-8">

<?php 

$con = mysqli_connect("localhost", "root","","productos") or die ("Error!"); 


?>

<html>
<head>
	<title>Evelyn♥ </title>
	</HEAD><H1><P ALIGN="CENTER"><FONT SIZE="10" COLOR="PURPLE" FACE="Monotype Corsiva"> TIENDA DE ROPA ♥</H1><B><B></FONT> <B><B>
	<meta charset="utf-8">
</head>
<body BACKGROUND="fondo.JPEG">
 <form method="POST" action="Producto.php" method="post" enctype="multipart/form-data">
 	<tr><td align="LEFT" rowspan="5"><img src="logo.jpg"/></td><td><label></label></td></tr>
 	<P ALIGN="RIGHT">
 		<label>#_producto:<br> </label>
	 <input type="text" name="no_producto" placeholder = ""><br />
	 <label>Producto:<br> </label>
	 <input type="text" name="nombre" placeholder = ""><br />
	 <label>Caracteristicas:<br></label>
	 <textarea style="border-radius: 10px;" rows="5" cols="30" name="descripcion"> </textarea><br /><br>
	 <label>Stock:<br></label>
	 <input type="text" name="stock" placeholder = ""><br /><br>
	 <label>Cantidad:<br></label>
	 <input type="text" name="precio" placeholder = ""><br /><br>
     <label>Imagen del producto<br></label>
	 <input type="file" name="imagen"><br /><br>
	 <input type="submit" name="insert" value = "Agregar a la tabla"><br /><br> <br /><br>
	 

 </form>

<?php
	if(isset($_POST["insert"])){
        $no_producto = $_POST["no_producto"];
		$nom = $_POST["nombre"];
		$des = $_POST["descripcion"];
		$stock = $_POST["stock"];
		$prec = $_POST["precio"];

copy($_FILES['imagen']['tmp_name'], $_FILES['imagen']['name']);
$no=$_FILES['imagen']['name'];
echo "<img src=\"$no\">";

		$insertar = "INSERT INTO producto (no_producto,nombre,descripcion,stock,precio,imagen) VALUES ('$no_producto', '$nom', '$des','$stock', '$prec','$no')";
		$ejecutar = mysqli_query($con, $insertar);

		if ($ejecutar){
			echo "<h3>Datos Insertado</h3>";
		}
	}
?>

<br/>
<center><table width="1300" border="0" style="background-color: #87CEFA; ">
	<tr>
		<th>no_producto</th>
		<th>Prenda</th>
		<th>descripcion</th>
		<th>stock</th>
        <th>Cantidad</th>
        <th>Borrar</th>
		<th>Editar </th>
		<th>imagen</th>
		
	</tr></center>
<?php


$consulta = "SELECT * FROM producto";
$ejecutar = mysqli_query($con, $consulta);
$i = 0;
while( $fila = mysqli_fetch_array($ejecutar)) {
	$Id = $fila['Id'];
	$no_producto = $fila['no_producto'];
	$nom = $fila['nombre'];
	$des = $fila['descripcion'];
    $stock = $fila['stock'];
	$prec = $fila['precio'];
    $no = $fila['imagen'];
	$i++;

?>
<td><?php echo $no_producto; ?></td>	
<td><?php echo $nom; ?></td>
<td><?php echo $des; ?></td>
<td><?php echo $stock; ?></td>
<td><?php echo $prec; ?></td>
<td><a href="Producto.php?editar=<?php echo $Id; ?>">Editar</a></td>
<td><a href="Producto.php?borrar=<?php echo $Id; ?>">Borrar</a></td>
<td><?php echo $no; ?></td>
</tr>
<?php 

	} 

?>
</table>

<?php
if(isset($_GET['editar'])){
	include("editar.php");
}

?>

<?php
if(isset($_GET['borrar'])){
	$borrar_id = $_GET['borrar'];
	$borrar = "DELETE FROM producto WHERE Id = '$borrar_id'";
	$ejecutar = mysqli_query($con, $borrar);

	if ($ejecutar){
		echo "<script>alert('SE BORRO EL USUARIO EXITOSAMENTE')</script>";
		echo "<script>windoows.open('Producto.php','_self')</script>";
	}

}
	
?>
<a href="crearPdf.php"> Generar ticket
      </a>
</body>
</html>
